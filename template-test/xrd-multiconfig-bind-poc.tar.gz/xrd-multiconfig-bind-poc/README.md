# XRd multi-config bind PoC

Image:
  sbezverk/xrd-control-plane:25.2.1

The goal is only to prove that a host directory can be exposed to an XRd
node and then determine which IOS XR filesystem alias maps to /xr-storage.

Deploy:
  containerlab deploy -t xrd-multiconfig-bind.clab.yml

1. Check the Docker-side bind:
  docker exec -it clab-xrd_multiconfig_bind-xr1 ls -la /xr-storage/labconfigs

Expected:
  LAB-001.cfg
  LAB-002.cfg
  LAB-003.cfg

2. From IOS XR, discover the filesystem mapping:
  show filesystem

  dir disk0:
  dir harddisk:
  dir /recurse disk0:
  dir /recurse harddisk:

The correct alias/path for the bind should reveal LAB-001.cfg etc.

3. Once the files are visible from IOS XR, test native loading.
Cisco IOS XR configuration-management documentation uses:
  configure
  load <filesystem>:<filename>
  show
  commit

For a full configuration replacement, use the appropriate IOS XR commit
replace workflow supported by the release.

IMPORTANT:
This PoC deliberately does NOT use a custom XRd image and does NOT use
scripts or docker restart for scenario switching. The only custom behavior is
the containerlab bind.

Official containerlab XRd documentation states that XRd has an xr-storage
directory mounted at /xr-storage and supports user-defined startup-config.
Containerlab also documents generic binds for exposing host files/directories
inside containerized nodes.
