#!/usr/bin/env bash
set -euo pipefail

NODE=${1:-r1}
LAB=${2:-}

if [[ -z "$LAB" ]]; then
  echo "Usage: $0 <node> <lab-001|lab-002|lab-003>"
  exit 1
fi

case "$LAB" in
  lab-001|lab-002|lab-003) ;;
  *) echo "Unknown lab: $LAB"; exit 1 ;;
esac

CONTAINER="clab-vjunos-switch-poc-${NODE}"
FILE="/config/labconfigs/${LAB}.conf"

echo "Loading $FILE on $NODE ..."
docker exec -i "$CONTAINER" cli <<JUNOS
configure
load override $FILE
show | compare
commit and-quit
JUNOS
