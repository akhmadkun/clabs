POC: vJunos-router bind directory + multiple configs

1. Edit vjunos-config-switch.clab.yml and replace REPLACE_WITH_YOUR_VJUNOS_IMAGE
   with the image tag you already use for juniper_vjunosrouter.

2. Deploy once:
   sudo containerlab deploy -t vjunos-config-switch.clab.yml

3. The host directory ./configs is bind-mounted into the vJunos container as:
   /config/labconfigs

4. Verify from the vJunos shell:
   docker exec -it clab-vjunos-switch-poc-r1 bash
   ls -l /config/labconfigs

5. Switch configuration without restarting the container:
   ./switch.sh r1 lab-001
   ./switch.sh r1 lab-002
   ./switch.sh r1 lab-003

6. Manual equivalent from Junos CLI:
   configure
   load override /config/labconfigs/lab-002.conf
   show | compare
   commit

Expected behavior:
- container stays running
- no docker restart
- no containerlab destroy/deploy
- Junos candidate config is replaced by the selected file
- commit activates the selected scenario

Important:
- These example files are deliberately small POC configs and may not represent the
  exact management configuration of your vJunos image.
- After load override, the loaded file becomes the whole candidate configuration.
  Therefore each scenario file should contain every configuration item you need to
  keep, including management access if you intend to keep SSH access.
- Keep the bind directory read-only for safety; Junos only needs to read the files.
