VSRX LOAD-REPLACE POC
=====================

Image:
  eacik8ssrv6/juniper_vsrx:23.2R2.21

External bridge:
  br-univ (must already exist on the host)

Purpose:
  1. Verify the local vSRX image works with kind: juniper_vsrx.
  2. Verify startup-config is applied.
  3. Verify host config directory is bind-mounted as /lab-config.
  4. Verify load replace works after vSRX is running.

Files:
  poc-vsrx.clab.yml
  configs/01-startup.conf
  configs/02-replace.conf

Deploy:
  containerlab deploy -t poc-vsrx.clab.yml

CLI:
  ssh admin@clab-ipsec-vsrx-poc-lr-vsrx-a
  password: admin@123

Or:
  docker exec -it clab-ipsec-vsrx-poc-lr-vsrx-a cli

Check startup config:
  show system host-name
  show interfaces ge-0/0/0 terse

Check bind:
  start shell
  ls -l /lab-config
  cat /lab-config/02-replace.conf
  exit

Test load replace:
  configure
  load replace /lab-config/02-replace.conf
  show | compare
  commit check
  commit

Expected:
  hostname: poc-vsrx-b
  ge-0/0/0.0 address: 198.18.20.12/24

Restore by loading the startup profile:
  configure
  load replace /lab-config/01-startup.conf
  show | compare

Note:
  01-startup.conf is intentionally a partial config. vSRX started by containerlab
  has a built-in default configuration, and containerlab applies user startup-config
  after the node starts.
