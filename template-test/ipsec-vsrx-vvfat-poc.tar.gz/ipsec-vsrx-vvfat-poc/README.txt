IPsec vSRX VVFAT / Bind-Directory PoC
====================================

Purpose
-------
Prove these two things on the user's exact image:

1. eacik8ssrv6/juniper_vsrx:23.2R2.21 boots under containerlab.
2. A HOST directory can be exposed to the vSRX guest through QEMU VVFAT,
   then a Junos config file from that directory can be used with:
       load replace /mnt/02.conf
   without using "load replace terminal", SCP, or an ISO.

Host directory
--------------
./configs is bind-mounted into the vrnetlab launcher as:
/lab-config

QEMU is then given:
    -drive file=fat:ro:/lab-config,if=ide,media=disk

This is QEMU's directory-backed virtual FAT disk. The guest is expected
to see an additional disk and mount it as a FAT filesystem.

Deploy
------
containerlab deploy -t poc-vsrx-vvfat.clab.yml

Wait for the vSRX to finish booting.

Enter the Junos CLI using the node's native management access.

Verify startup config
---------------------
show system host-name
show interfaces ge-0/0/0 terse

Expected:
    hostname: poc-vsrx-a
    ge-0/0/0.0: 198.18.10.12/24

Verify the VVFAT disk from Junos shell
--------------------------------------
start shell

Then inspect devices:
    dmesg | egrep -i 'ad[0-9]|da[0-9]|cd[0-9]|ata|disk'
    sysctl kern.disks

Try to identify the extra disk. With an IDE hard disk it will commonly
be an additional "adN" device, but do not assume the exact name.

Example (adjust device name if different):
    mkdir -p /mnt/lab-config
    mount -t msdosfs /dev/ad1 /mnt/lab-config
    ls -la /mnt/lab-config

You should see:
    startup.conf
    01.conf
    02.conf

Load replace test
-----------------
Return to Junos CLI:
    exit
    configure
    load replace /mnt/lab-config/01.conf
    show | compare
    commit check
    commit

Expected changes:
    hostname -> vvfat-test-1
    ge-0/0/0.0 address -> 198.18.20.12/24

Then test another file WITHOUT recreating the node:
    load replace /mnt/lab-config/02.conf
    show | compare
    commit

Expected:
    hostname -> vvfat-test-2
    ge-0/0/0.0 address -> 198.18.30.12/24

Important
---------
- This PoC intentionally has NO scripts.
- The host bridge br-univ must already exist.
- The VVFAT disk is read-only from the guest.
- QEMU_ADDITIONAL_ARGS is the key variable; containerlab documents it
  for vrnetlab VM-based nodes.
- If the container starts but the QEMU process rejects the -drive
  argument, inspect:
      docker logs clab-ipsec-vsrx-vvfat-poc-vsrx-a
  and the image's vrnetlab version/launcher implementation.
