IPsec Cookbook Lab - Image PoC

Purpose
-------
Before building the universal topology, validate the two Juniper firewall image
kinds and the startup-config mechanism independently.

Host bridge
-----------
Both PoCs reference an existing host Linux bridge named:
    br-univ

The bridge must already exist before deploy. Containerlab's bridge kind does not
create host-bound bridges.

PoC 1 - cSRX
------------
Topology: poc-csrx.clab.yml
Image: meekley/csrx:23.4R1.9
Startup config: configs/csrx-a.conf
Junos data interface: ge-0/0/0
Expected address: 198.18.10.11/24

Deploy:
    sudo containerlab deploy -t poc-csrx.clab.yml

Verify:
    sudo docker exec -it clab-ipsec-poc-csrx-csrx-a cli -c 'show version | match JUNOS'
    sudo docker exec -it clab-ipsec-poc-csrx-csrx-a cli -c 'show configuration system host-name'
    sudo docker exec -it clab-ipsec-poc-csrx-csrx-a cli -c 'show interfaces terse ge-0/0/0'
    sudo docker exec -it clab-ipsec-poc-csrx-csrx-a cli -c 'show interfaces ge-0/0/0'

PoC 2 - vSRX
------------
Topology: poc-vsrx.clab.yml
Image: eacik8ssrv6/juniper_vsrx:23.2R2.21
Startup config: configs/vsrx-a.conf
Junos data interface: ge-0/0/0
Expected address: 198.18.10.12/24

Deploy:
    sudo containerlab deploy -t poc-vsrx.clab.yml

Verify:
    sudo docker logs clab-ipsec-poc-vsrx-vsrx-a 2>&1 | tail -n 80
    sudo docker exec -it clab-ipsec-poc-vsrx-vsrx-a cli -c 'show version | match JUNOS'
    sudo docker exec -it clab-ipsec-poc-vsrx-vsrx-a cli -c 'show configuration system host-name'
    sudo docker exec -it clab-ipsec-poc-vsrx-vsrx-a cli -c 'show interfaces terse ge-0/0/0'
    sudo docker exec -it clab-ipsec-poc-vsrx-vsrx-a cli -c 'show interfaces ge-0/0/0'

Success criteria
----------------
1. Container reaches running/healthy state.
2. Startup config is accepted, not rejected/fallback.
3. Hostname is poc-csrx-a / poc-vsrx-a.
4. ge-0/0/0 exists and is configured with the expected address.
5. We can enter Junos CLI.

Important
---------
Do not test both labs simultaneously at first. Validate cSRX, destroy it,
then validate vSRX. This keeps resource usage and failure diagnosis simple.

If both PoCs pass, the next step is the single universal topology.

Recommended validation order
----------------------------
1. Run scripts/check-host.sh
2. Deploy cSRX PoC
3. Run scripts/verify-csrx.sh
4. Destroy cSRX PoC
5. Deploy vSRX PoC
6. Run scripts/verify-vsrx.sh
7. Destroy vSRX PoC

Do not interpret a successful container start alone as startup-config success.
The decisive checks are the hostname and ge-0/0/0 address in the Junos CLI.
For cSRX, also inspect /var/log/csrx_start.log if the custom config is rejected.

Why PoC before the universal topology?
--------------------------------------
The cSRX and vSRX containerlab integrations use different startup mechanisms.
cSRX is a native containerized kind; vSRX is a vrnetlab/QEMU VM inside a
container. Both support user startup configuration, but they do not apply it
through the same underlying mechanism. Validate them independently first.

Future universal-topology design
--------------------------------
After these PoCs pass, build one topology with fixed physical links and keep
lab profiles separate from the topology. For profile switching, we can choose
between:
  A) redeploy/reconfigure with a different startup-config profile, or
  B) keep the nodes running and push the profile over SSH/NETCONF.
Option B is likely the cleaner long-term workflow if the goal is to switch
between many cookbook labs without recreating the physical topology.
