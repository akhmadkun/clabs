#!/usr/bin/env bash
set -euo pipefail
C=clab-ipsec-poc-vsrx-vsrx-a

echo '== container =='
docker inspect -f 'status={{.State.Status}} health={{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$C"

echo

echo '== hostname =='
docker exec "$C" cli -c 'show configuration system host-name'

echo

echo '== ge-0/0/0 =='
docker exec "$C" cli -c 'show interfaces terse ge-0/0/0'
echo

echo '== recent container log =='
docker logs --tail 80 "$C" 2>&1
