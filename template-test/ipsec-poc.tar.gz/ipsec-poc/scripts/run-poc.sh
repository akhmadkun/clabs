#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

usage() {
  echo "Usage: $0 {csrx|vsrx|destroy-csrx|destroy-vsrx}"
  exit 1
}

case "${1:-}" in
  csrx)
    sudo containerlab deploy -t poc-csrx.clab.yml
    ;;
  vsrx)
    sudo containerlab deploy -t poc-vsrx.clab.yml
    ;;
  destroy-csrx)
    sudo containerlab destroy -t poc-csrx.clab.yml --cleanup
    ;;
  destroy-vsrx)
    sudo containerlab destroy -t poc-vsrx.clab.yml --cleanup
    ;;
  *) usage ;;
esac
