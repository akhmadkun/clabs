#!/usr/bin/env bash
set -euo pipefail

echo '== Containerlab =='
containerlab version

echo
echo '== Required Docker images =='
for img in \
  'meekley/csrx:23.4R1.9' \
  'eacik8ssrv6/juniper_vsrx:23.2R2.21'; do
  docker image inspect "$img" >/dev/null 2>&1 \
    && echo "OK    $img" \
    || { echo "MISS  $img"; exit 1; }
done

echo
echo '== External bridge =='
ip link show br-univ

echo 'OK    br-univ exists'
