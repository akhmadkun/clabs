#!/usr/bin/env bash
set -euo pipefail
C=clab-ipsec-poc-csrx-csrx-a

echo '== container =='
docker inspect -f 'status={{.State.Status}} health={{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$C"

echo

echo '== hostname =='
docker exec "$C" cli -c 'show configuration system host-name'

echo

echo '== ge-0/0/0 =='
docker exec "$C" cli -c 'show interfaces terse ge-0/0/0'
echo

echo '== startup/load log =='
docker exec "$C" sh -c 'grep -Ei "(load|config|error|fail)" /var/log/csrx_start.log | tail -n 40 || true'
