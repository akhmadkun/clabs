cSRX 23.4R1.9 + containerlab PoC
================================

Purpose
-------
1. Prove the local cSRX image can run as kind: juniper_csrx.
2. Prove startup-config is applied.
3. Prove Junos 'load replace <file>' works AFTER the node is already running.
4. Prove we can replace config B and then replace config A again without rebuilding the topology.

Host assumption
---------------
The existing host Linux bridge must already exist as br-univ.
Containerlab does not create the host bridge.

Image
-----
meekley/csrx:23.4R1.9

Run
---
./scripts/run-test.sh

The test intentionally uses only one data interface:
  cSRX eth1 -> br-univ
  Junos ge-0/0/0 -> 198.18.10.1/24 initially

Config A at boot:
  hostname poc-csrx-a
  ge-0/0/0.0 = 198.18.10.1/24

Config B via load replace after boot:
  hostname poc-csrx-b
  ge-0/0/0.0 = 198.18.20.1/24

Then config A is loaded again with load replace.

Useful manual commands
----------------------
containerlab deploy -t poc-csrx.clab.yml
./scripts/wait-ready.sh
./scripts/verify-startup.sh
./scripts/load-replace.sh configs/02-replace.conf
./scripts/restore-startup.sh
containerlab destroy -t poc-csrx.clab.yml

Important
---------
The replacement files are deliberately minimal because this PoC is testing the loader, not a production management configuration. A load replace replaces the entire candidate configuration. For the future universal lab, each lab profile should therefore be a complete configuration that preserves the cSRX management access requirements.

Troubleshooting
---------------
If startup config is rejected:
  docker exec ipsec-csrx-poc-csrx-a sh -c 'tail -n 100 /var/log/csrx_start.log'

If load replace fails, inspect the exact 'show | compare' and 'commit check' output from load-replace.sh.
