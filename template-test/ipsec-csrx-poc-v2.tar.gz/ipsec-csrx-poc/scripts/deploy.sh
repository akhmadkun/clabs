#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! ip link show br-univ >/dev/null 2>&1; then
  echo "ERROR: host bridge br-univ does not exist."
  exit 1
fi

if ! docker image inspect meekley/csrx:23.4R1.9 >/dev/null 2>&1; then
  echo "ERROR: image meekley/csrx:23.4R1.9 not found."
  exit 1
fi

containerlab deploy -t poc-csrx.clab.yml
