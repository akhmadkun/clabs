#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
containerlab destroy -t poc-csrx.clab.yml
