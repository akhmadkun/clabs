#!/usr/bin/env bash
set -euo pipefail
C="ipsec-csrx-poc-csrx-a"

echo '=== IMAGE / VERSION ==='
docker image inspect meekley/csrx:23.4R1.9 --format 'RepoTags={{json .RepoTags}} Id={{.Id}} Size={{.Size}}'

echo

echo '=== STARTUP CONFIG VERIFICATION ==='
docker exec "$C" cli -c 'show configuration system host-name'
docker exec "$C" cli -c 'show interfaces ge-0/0/0 terse'
docker exec "$C" cli -c 'show configuration interfaces ge-0/0/0'
