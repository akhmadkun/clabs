#!/usr/bin/env bash
set -euo pipefail
C="ipsec-csrx-poc-csrx-a"

for i in {1..60}; do
  if docker exec "$C" cli -c 'show version | match JUNOS' >/tmp/csrx-version.out 2>/dev/null; then
    echo "cSRX CLI is ready."
    cat /tmp/csrx-version.out
    exit 0
  fi
  printf '.'
  sleep 5
done

echo
echo "ERROR: cSRX CLI did not become ready."
docker logs "$C" --tail 100 || true
exit 1
