#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

C="ipsec-csrx-poc-csrx-a"
CFG="${1:-configs/02-replace.conf}"

if [[ ! -f "$CFG" ]]; then
  echo "ERROR: config not found: $CFG"
  exit 1
fi

docker cp "$CFG" "$C:/tmp/poc-replace.conf"

echo "=== CANDIDATE CONFIG DIFF ==="
docker exec -i "$C" cli <<'JUNOS'
configure
load replace /tmp/poc-replace.conf
show | compare
commit check
exit
JUNOS

echo
echo "=== COMMITTING REPLACEMENT ==="
docker exec -i "$C" cli <<'JUNOS'
configure
load replace /tmp/poc-replace.conf
commit and-quit
JUNOS

echo
echo "=== POST-REPLACE VERIFICATION ==="
docker exec "$C" cli -c 'show configuration system host-name'
docker exec "$C" cli -c 'show interfaces ge-0/0/0 terse'
docker exec "$C" cli -c 'show configuration interfaces ge-0/0/0'
