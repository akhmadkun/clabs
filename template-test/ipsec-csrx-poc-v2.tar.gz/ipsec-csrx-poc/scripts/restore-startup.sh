#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
C="ipsec-csrx-poc-csrx-a"
CFG="configs/01-startup.conf"

docker cp "$CFG" "$C:/tmp/poc-restore.conf"

docker exec -i "$C" cli <<'JUNOS'
configure
load replace /tmp/poc-restore.conf
show | compare
commit and-quit
JUNOS

echo '=== RESTORED ==='
docker exec "$C" cli -c 'show configuration system host-name'
docker exec "$C" cli -c 'show interfaces ge-0/0/0 terse'
