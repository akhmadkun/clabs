#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

./scripts/deploy.sh
./scripts/wait-ready.sh
./scripts/verify-startup.sh

echo
echo '### TEST 1 PASSED: image boot + startup-config loaded'

echo
echo '### TEST 2: load replace -> config B'
./scripts/load-replace.sh configs/02-replace.conf

echo
echo '### TEST 3: load replace -> config A again'
./scripts/restore-startup.sh

echo
echo 'ALL cSRX PoC TESTS COMPLETED'
