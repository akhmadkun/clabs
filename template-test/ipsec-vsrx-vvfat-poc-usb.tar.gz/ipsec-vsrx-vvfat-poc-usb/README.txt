vSRX VVFAT bind-directory PoC (USB storage attachment)

Image:
  eacik8ssrv6/juniper_vsrx:23.2R2.21

Why USB:
  The earlier PoC attached the directory-backed VVFAT filesystem as an IDE
  disk:
      -drive file=fat:rw:/lab-config,if=ide,media=disk
  That made the vSRX startup hang.

  This PoC uses the QEMU pattern:
      -drive if=none,id=labdisk,format=raw,file=fat:rw:/lab-config
      -device usb-storage,drive=labdisk

The host directory is bind-mounted into the vrnetlab launcher:
      ./configs -> /lab-config

The guest should see the VVFAT backend as a USB mass-storage device.

Deploy:
  containerlab deploy -t poc-vsrx-vvfat-usb.clab.yml

After vSRX boots:
  start shell

Find the new disk:
  dmesg | egrep -i 'da[0-9]|ad[0-9]|umass|usb|disk'
  sysctl kern.disks

Do not assume the disk name. It may be a daN device because it is attached
through USB mass storage.

Example:
  mkdir -p /mnt/lab-config
  mount -t msdosfs -o ro /dev/da1 /mnt/lab-config
  ls -la /mnt/lab-config

Expected files:
  startup.conf
  01.conf
  02.conf

Then:
  exit
  configure
  load replace /mnt/lab-config/01.conf
  show | compare
  commit

Then, without recreating the node:
  load replace /mnt/lab-config/02.conf
  show | compare
  commit

Important:
- No scripts are used.
- br-univ must already exist.
- The VVFAT backend is opened RW because modern QEMU can reject the RO
  VVFAT block setup; mount it RO in the guest.
- The primary goal is to verify that the exact vSRX image can boot while
  receiving a directory-backed VVFAT disk and that Junos can read files from it.
